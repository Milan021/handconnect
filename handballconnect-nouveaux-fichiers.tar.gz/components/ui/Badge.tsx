type BadgeVariant = "blue" | "cyan" | "orange" | "gray" | "green";

const variants: Record<BadgeVariant, string> = {
  blue: "bg-hc-blue/10 text-hc-blue border-hc-blue/20",
  cyan: "bg-hc-cyan/10 text-emerald-400 border-hc-cyan/15",
  orange: "bg-hc-orange/10 text-orange-400 border-hc-orange/15",
  gray: "bg-white/5 text-white/50 border-white/10",
  green: "bg-green-500/10 text-green-400 border-green-500/15",
};

export function Badge({
  children,
  variant = "blue",
}: {
  children: React.ReactNode;
  variant?: BadgeVariant;
}) {
  return (
    <span
      className={`inline-block px-2.5 py-0.5 rounded-full text-[10.5px] font-bold tracking-wide uppercase border ${variants[variant]}`}
    >
      {children}
    </span>
  );
}
