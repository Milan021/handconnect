// lib/data.ts — Types & données HandballConnect

export interface Annonce {
  id: string;
  title: string;
  club: string;
  dept: string;
  deptName: string;
  postType: string;
  contractType: string;
  level: string;
  description: string;
  quote: string;
  contactName: string;
  contactRole: string;
  contactEmail: string;
  contactPhone: string;
  date: string;
  source: string;
}

export const DEPARTMENTS: Record<string, string> = {
  "01": "Ain",
  "03": "Allier",
  "07": "Ardèche",
  "15": "Cantal",
  "26": "Drôme",
  "38": "Isère",
  "42": "Loire",
  "43": "Haute-Loire",
  "63": "Puy-de-Dôme",
  "69": "Rhône",
  "73": "Savoie",
  "74": "Haute-Savoie",
};

export const POST_TYPES = [
  "Entraîneur",
  "Arbitre",
  "Dirigeant",
  "Animateur",
  "Responsable technique",
  "Autre",
];

export const CONTRACT_TYPES = [
  "Bénévole",
  "CDD",
  "CDI",
  "Stage",
  "Service civique",
];

// Données initiales — à migrer vers Supabase plus tard
export const ANNONCES: Annonce[] = [
  {
    id: "1",
    title: "Entraîneur Senior Garçons",
    club: "US Meyzieu Handball",
    dept: "69",
    deptName: "Rhône",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-24",
    level: "Excellence Régionale",
    description:
      "Recherche un entraineur pour l'équipe sénior garçon 1 évoluant en Excellence Régionale. 2 à 3 entrainements par semaine avec création et animation de séance. Coaching le week-end. Gestion équipe 1 et 2. Tous les profils sont étudiés.",
    quote:
      "Nous sommes un club avec de vrais objectifs sportifs et la volonté d'avoir une montée en Pré-National sur 4 ans.",
    contactName: "Carla BOUCHER",
    contactRole: "Directrice technique",
    contactEmail: "bouchercarla@gmail.com",
    contactPhone: "06 44 38 16 05",
    source: "Ligue AURA",
  },
  {
    id: "2",
    title: "Entraîneurs Staff Technique",
    club: "Cheyenne Handball",
    dept: "73",
    deptName: "Savoie",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-24",
    level: "Honneur / Div1 Départementale",
    description:
      "Renforcement du staff technique : Entraîneur seniors masculins (Honneur ou Div1 départementale) + 1 équipe en division 2. Entraîneur seniors féminines (Div1 départementale). Missions : accompagner les joueurs, préparer et animer les séances.",
    quote: "",
    contactName: "Romain BONNET",
    contactRole: "Président",
    contactEmail: "cheyennehandball@gmail.com",
    contactPhone: "06 68 12 57 79",
    source: "Ligue AURA",
  },
  {
    id: "3",
    title: "Coachs Jeunes H/F",
    club: "Handball Trévoux Saône Vallée",
    dept: "01",
    deptName: "Ain",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-23",
    level: "Catégories jeunes",
    description:
      "Recherche coachs (H/F) pour encadrer les catégories jeunes filles (-11, -13) et garçons (-9 à -18). À confirmer : coach +16M (D2 ou D1). Expérience et qualification fédérale appréciées. Club situé à 10 minutes de Villefranche-sur-Saône.",
    quote: "",
    contactName: "Jean-Marc SEVE",
    contactRole: "Président",
    contactEmail: "coachstvxhb@gmail.com",
    contactPhone: "06 99 20 39 00",
    source: "Ligue AURA",
  },
  {
    id: "4",
    title: "Entraîneurs Baby/Jeunes/Seniors",
    club: "Beaujolais Val de Saône Handball",
    dept: "69",
    deptName: "Rhône",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-22",
    level: "Toutes catégories",
    description:
      "Recherche entraîneurs babyhand / -7 ans / -9 ans et entraîneur seniors masculins. Missions : accompagner et gérer les joueurs, préparer et animer les séances d'entraînement et les matchs.",
    quote: "",
    contactName: "Adeline LHERMITTE",
    contactRole: "Présidente",
    contactEmail: "présidentbvsh@gmail.com",
    contactPhone: "06 23 66 72 36",
    source: "Ligue AURA",
  },
  {
    id: "5",
    title: "Entraîneur Seniors Pré-Nationale",
    club: "Handball Club Romanais",
    dept: "26",
    deptName: "Drôme",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-22",
    level: "Pré-Nationale / 1re Div Territoriale",
    description:
      "Recherche entraîneur pour les équipes seniors Pré-Nationale et 1re Division Territoriale. Entraînements mardis et vendredis. Tous profils étudiés. Recherche aussi des membres pour renforcer le staff senior. Projet sur 2 à 3 ans.",
    quote:
      "Le HBCR s'appuie sur un groupe de joueurs jeunes, ambitieux et fidèles au club, dans une dynamique de structuration portée par une équipe dirigeante motivée.",
    contactName: "Brian BOURVARD",
    contactRole: "Président",
    contactEmail: "5126017@ffhandball.net",
    contactPhone: "06 75 48 91 44",
    source: "Ligue AURA",
  },
  {
    id: "6",
    title: "Entraîneur Senior Garçons",
    club: "Handball Club de Rumilly",
    dept: "74",
    deptName: "Haute-Savoie",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-22",
    level: "Excellence Régionale",
    description:
      "Recherche entraîneur pour le collectif senior garçon saison 2026-2027. 2 équipes en séniors masculin dont l'équipe fanion en Excellence Régionale. 2 entraînements/semaine + coaching weekend. Situé à 20mn d'Annecy et 40mn de Chambéry.",
    quote:
      "Nous avons à cœur de construire un projet sportif masculin attractif pour ce groupe jeune dynamique et motivé, issu principalement de nos U18 !",
    contactName: "Martine DEPLANTE",
    contactRole: "Présidente",
    contactEmail: "presidente@handballclubrumilly.com",
    contactPhone: "06 37 33 76 29",
    source: "Ligue AURA",
  },
  {
    id: "7",
    title: "Entraîneur(e) Seniors Féminines",
    club: "Handball Club Aix en Savoie",
    dept: "73",
    deptName: "Savoie",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-22",
    level: "Seniors féminines",
    description:
      "Recherche un(e) entraîneur(e) pour les équipes seniors féminines pour la saison prochaine. Rejoignez une structure dynamique et contribuez au développement du handball féminin.",
    quote:
      "Rejoignez une structure dynamique et contribuez au développement du handball féminin.",
    contactName: "",
    contactRole: "",
    contactEmail: "contact@hbcaixensavoie.fr",
    contactPhone: "",
    source: "Ligue AURA",
  },
  {
    id: "8",
    title: "Entraîneurs/Entraîneuses",
    club: "Pays Voironnais Handball",
    dept: "38",
    deptName: "Isère",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-21",
    level: "Tous niveaux",
    description:
      "Recherche entraîneurs/entraîneuses pour renforcer l'encadrement et améliorer l'accompagnement des licenciés, saison 2026-2027. Tous profils étudiés : diplômés, en formation, anciens joueurs, bénévoles motivés, jeunes coachs.",
    quote:
      "Ce qu'on t'offre : un club structuré et humain, un projet sportif ambitieux, un accompagnement dans ta formation, une vraie place dans la vie du club.",
    contactName: "",
    contactRole: "",
    contactEmail: "5138069@ffhandball.net",
    contactPhone: "",
    source: "Ligue AURA",
  },
  {
    id: "9",
    title: "Entraîneur Senior Filles",
    club: "ASMC Handball Marcy l'Étoile",
    dept: "69",
    deptName: "Rhône",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-04-21",
    level: "Départemental",
    description:
      "Club d'environ 300 licenciés, recherche entraîneur pour l'équipe sénior filles en départemental avec volonté de monter. Filière féminine en structuration : -13, -15, -18 et 2 équipes senior filles. Entraînements lundi et jeudi soir.",
    quote: "",
    contactName: "Luc MOUNIER",
    contactRole: "Président",
    contactEmail: "5169036@ffhandball.net",
    contactPhone: "06 08 55 24 54",
    source: "Ligue AURA",
  },
  {
    id: "10",
    title: "Entraîneurs Saison 2026-2027",
    club: "Bron Handball",
    dept: "69",
    deptName: "Rhône",
    postType: "Entraîneur",
    contractType: "Bénévole",
    date: "2026-03-03",
    level: "Filière féminine + staff",
    description:
      "Recherche entraîneur filière féminine (-15 et -18 ans) et entraîneurs pour renforcer le staff technique. Missions : motiver et accompagner les joueurs/joueuses, préparer les séances, former les jeunes, analyser la performance.",
    quote: "",
    contactName: "",
    contactRole: "",
    contactEmail: "",
    contactPhone: "",
    source: "Ligue AURA",
  },
];

export function getAnnonce(id: string): Annonce | undefined {
  return ANNONCES.find((a) => a.id === id);
}

export function formatDate(dateStr: string): string {
  return new Date(dateStr).toLocaleDateString("fr-FR", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}
