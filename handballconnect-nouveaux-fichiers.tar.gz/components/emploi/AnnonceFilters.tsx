"use client";

import { DEPARTMENTS, POST_TYPES, CONTRACT_TYPES } from "@/lib/data";

interface FiltersProps {
  search: string;
  dept: string;
  postType: string;
  contractType: string;
  onSearch: (v: string) => void;
  onDept: (v: string) => void;
  onPostType: (v: string) => void;
  onContractType: (v: string) => void;
}

const selectClass =
  "px-3.5 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[13px] text-white/80 font-medium outline-none focus:border-hc-blue transition-colors appearance-none cursor-pointer";

export function AnnonceFilters({
  search,
  dept,
  postType,
  contractType,
  onSearch,
  onDept,
  onPostType,
  onContractType,
}: FiltersProps) {
  return (
    <div className="flex gap-2.5 flex-wrap mb-5 animate-fade-up">
      <input
        type="text"
        value={search}
        onChange={(e) => onSearch(e.target.value)}
        placeholder="🔍 Rechercher un club, un poste..."
        className="flex-1 min-w-[200px] px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[13px] text-white placeholder:text-white/30 outline-none focus:border-hc-blue transition-colors"
      />
      <select
        value={dept}
        onChange={(e) => onDept(e.target.value)}
        className={selectClass}
      >
        <option value="">Tous départements</option>
        {Object.entries(DEPARTMENTS).map(([k, v]) => (
          <option key={k} value={k}>
            {v} ({k})
          </option>
        ))}
      </select>
      <select
        value={postType}
        onChange={(e) => onPostType(e.target.value)}
        className={selectClass}
      >
        <option value="">Tous postes</option>
        {POST_TYPES.map((p) => (
          <option key={p} value={p}>
            {p}
          </option>
        ))}
      </select>
      <select
        value={contractType}
        onChange={(e) => onContractType(e.target.value)}
        className={selectClass}
      >
        <option value="">Tous contrats</option>
        {CONTRACT_TYPES.map((c) => (
          <option key={c} value={c}>
            {c}
          </option>
        ))}
      </select>
    </div>
  );
}
