"use client";

import { useState } from "react";

const inputClass =
  "w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[13.5px] text-white placeholder:text-white/30 outline-none focus:border-hc-blue transition-colors";

export function ApplicationForm({ clubName }: { clubName: string }) {
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    nom: "",
    email: "",
    tel: "",
    experience: "",
    message: "",
  });

  const u = (k: string, v: string) => setForm({ ...form, [k]: v });

  if (sent) {
    return (
      <div className="text-center py-12 animate-fade-up">
        <div className="text-5xl mb-3">✅</div>
        <h3 className="text-lg font-bold mb-1.5">Candidature envoyée !</h3>
        <p className="text-sm text-white/45">
          Le club {clubName} recevra votre candidature. Bonne chance !
        </p>
      </div>
    );
  }

  return (
    <div className="animate-fade-up stagger-2">
      <h3 className="text-lg font-bold mb-4">📩 Candidater pour ce poste</h3>

      <div className="grid sm:grid-cols-2 gap-3 mb-3">
        <div>
          <label className="block text-[12px] font-semibold text-white/50 mb-1">
            Nom complet *
          </label>
          <input
            className={inputClass}
            value={form.nom}
            onChange={(e) => u("nom", e.target.value)}
            placeholder="Jean Dupont"
          />
        </div>
        <div>
          <label className="block text-[12px] font-semibold text-white/50 mb-1">
            Email *
          </label>
          <input
            className={inputClass}
            type="email"
            value={form.email}
            onChange={(e) => u("email", e.target.value)}
            placeholder="jean@email.com"
          />
        </div>
      </div>

      <div className="grid sm:grid-cols-2 gap-3 mb-3">
        <div>
          <label className="block text-[12px] font-semibold text-white/50 mb-1">
            Téléphone
          </label>
          <input
            className={inputClass}
            value={form.tel}
            onChange={(e) => u("tel", e.target.value)}
            placeholder="06 XX XX XX XX"
          />
        </div>
        <div>
          <label className="block text-[12px] font-semibold text-white/50 mb-1">
            Expérience
          </label>
          <select
            className={inputClass}
            value={form.experience}
            onChange={(e) => u("experience", e.target.value)}
          >
            <option value="">Sélectionner</option>
            <option>Débutant — Pas d&apos;expérience</option>
            <option>Joueur(se) reconverti(e)</option>
            <option>1 à 3 ans d&apos;expérience</option>
            <option>3+ ans d&apos;expérience</option>
            <option>Diplômé(e) fédéral</option>
          </select>
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-[12px] font-semibold text-white/50 mb-1">
          Message de motivation *
        </label>
        <textarea
          className={`${inputClass} min-h-[100px] resize-y`}
          value={form.message}
          onChange={(e) => u("message", e.target.value)}
          placeholder="Présentez-vous brièvement et expliquez votre motivation..."
        />
      </div>

      <button
        onClick={() => setSent(true)}
        className="px-7 py-3 rounded-xl bg-gradient-to-br from-hc-blue to-blue-700 text-white text-sm font-bold shadow-lg shadow-hc-blue/25 hover:-translate-y-0.5 hover:shadow-hc-blue/40 transition-all"
      >
        Envoyer ma candidature 🚀
      </button>
    </div>
  );
}
