"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

const links = [
  { href: "/", label: "Accueil" },
  { href: "/emploi", label: "Emploi" },
  { href: "#annuaire", label: "Annuaire" },
  { href: "#actus", label: "Actus" },
  { href: "#resultats", label: "Résultats" },
];

export function Navbar() {
  const pathname = usePathname();

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 backdrop-blur-xl bg-navy/85 border-b border-white/5">
      <div className="max-w-6xl mx-auto px-5 flex items-center justify-between h-14">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 group">
          <span className="text-2xl group-hover:scale-110 transition-transform">
            🤾
          </span>
          <span className="text-lg font-[900] tracking-tight bg-gradient-to-r from-white to-hc-cyan bg-clip-text text-transparent">
            HandballConnect
          </span>
        </Link>

        {/* Links */}
        <div className="flex items-center gap-1">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`px-3 py-1.5 rounded-lg text-[13px] font-semibold transition-all hidden sm:block ${
                pathname === link.href
                  ? "text-white bg-hc-blue/25"
                  : "text-white/50 hover:text-white hover:bg-white/5"
              }`}
            >
              {link.label}
            </Link>
          ))}
          <Link
            href="/emploi/poster"
            className="ml-2 px-4 py-1.5 rounded-xl bg-gradient-to-br from-hc-blue to-blue-700 text-white text-[13px] font-bold shadow-lg shadow-hc-blue/30 hover:-translate-y-0.5 hover:shadow-hc-blue/40 transition-all"
          >
            + Déposer
          </Link>
        </div>
      </div>
    </nav>
  );
}
