import { notFound } from "next/navigation";
import Link from "next/link";
import { getAnnonce, formatDate, ANNONCES } from "@/lib/data";
import { Badge } from "@/components/ui/Badge";
import { ApplicationForm } from "@/components/emploi/ApplicationForm";

export function generateStaticParams() {
  return ANNONCES.map((a) => ({ id: a.id }));
}

export default async function AnnonceDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = await params;
  const annonce = getAnnonce(id);

  if (!annonce) return notFound();

  return (
    <div className="pt-14 max-w-3xl mx-auto px-4 py-8">
      {/* Back */}
      <Link
        href="/emploi"
        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-white/[0.08] bg-white/[0.03] text-white/50 text-[13px] font-semibold hover:border-hc-blue hover:text-hc-blue transition-all mb-5"
      >
        ← Retour aux annonces
      </Link>

      {/* Card */}
      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden animate-fade-up">
        {/* Hero */}
        <div className="px-6 py-7 bg-gradient-to-br from-navy-mid to-navy-light">
          <div className="flex gap-1.5 flex-wrap mb-3">
            <Badge variant="blue">{annonce.postType}</Badge>
            <Badge variant="cyan">{annonce.contractType}</Badge>
            {annonce.level && <Badge variant="gray">{annonce.level}</Badge>}
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold mb-1">
            {annonce.title}
          </h1>
          <p className="text-sm text-white/50">
            {annonce.club} — {annonce.deptName} ({annonce.dept})
          </p>
          <p className="text-xs text-white/30 mt-2">
            Publiée le {formatDate(annonce.date)}
          </p>
        </div>

        {/* Content */}
        <div className="px-6 py-6">
          {/* Description */}
          <section className="mb-6">
            <h2 className="text-[11px] uppercase tracking-[1.2px] text-white/35 font-bold mb-2">
              Description du poste
            </h2>
            <p className="text-sm text-white/55 leading-relaxed">
              {annonce.description}
            </p>
          </section>

          {/* Quote */}
          {annonce.quote && (
            <section className="mb-6">
              <h2 className="text-[11px] uppercase tracking-[1.2px] text-white/35 font-bold mb-2">
                Le mot du club
              </h2>
              <blockquote className="pl-4 border-l-2 border-hc-blue bg-hc-blue/[0.03] rounded-r-xl py-3 pr-4 text-base text-white/70 italic leading-relaxed font-serif">
                « {annonce.quote} »
              </blockquote>
            </section>
          )}

          {/* Contact */}
          <section className="mb-6">
            <h2 className="text-[11px] uppercase tracking-[1.2px] text-white/35 font-bold mb-2">
              Contact
            </h2>
            <div className="grid sm:grid-cols-2 gap-2.5">
              {annonce.contactName && (
                <div className="px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <small className="block text-[10px] text-white/30 uppercase tracking-wider font-bold mb-0.5">
                    Personne
                  </small>
                  <span className="text-[13px] font-semibold">
                    {annonce.contactName}
                    {annonce.contactRole && (
                      <span className="text-white/40 font-normal">
                        {" "}
                        — {annonce.contactRole}
                      </span>
                    )}
                  </span>
                </div>
              )}
              {annonce.contactEmail && (
                <div className="px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <small className="block text-[10px] text-white/30 uppercase tracking-wider font-bold mb-0.5">
                    Email
                  </small>
                  <span className="text-[13px] font-semibold text-hc-blue break-all">
                    {annonce.contactEmail}
                  </span>
                </div>
              )}
              {annonce.contactPhone && (
                <div className="px-4 py-3 rounded-xl bg-white/[0.03] border border-white/[0.06]">
                  <small className="block text-[10px] text-white/30 uppercase tracking-wider font-bold mb-0.5">
                    Téléphone
                  </small>
                  <span className="text-[13px] font-semibold text-emerald-400">
                    {annonce.contactPhone}
                  </span>
                </div>
              )}
            </div>
          </section>
        </div>
      </div>

      {/* Application Form */}
      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-6 mt-4">
        <ApplicationForm clubName={annonce.club} />
      </div>
    </div>
  );
}
