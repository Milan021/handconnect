"use client";

import { useState } from "react";
import Link from "next/link";
import { DEPARTMENTS, POST_TYPES, CONTRACT_TYPES } from "@/lib/data";

const inputClass =
  "w-full px-4 py-2.5 rounded-xl bg-white/[0.04] border border-white/[0.08] text-[13.5px] text-white placeholder:text-white/30 outline-none focus:border-hc-blue transition-colors";

export default function PosterPage() {
  const [submitted, setSubmitted] = useState(false);

  if (submitted) {
    return (
      <div className="pt-14 max-w-2xl mx-auto px-4 py-20 text-center animate-fade-up">
        <div className="text-5xl mb-4">🎉</div>
        <h2 className="text-2xl font-extrabold mb-2">Annonce publiée !</h2>
        <p className="text-sm text-white/45 max-w-sm mx-auto leading-relaxed mb-6">
          Votre annonce est désormais visible sur HandballConnect. Les candidats
          pourront vous contacter directement.
        </p>
        <div className="flex gap-3 justify-center">
          <Link
            href="/emploi"
            className="px-6 py-2.5 rounded-xl bg-gradient-to-br from-hc-blue to-blue-700 text-white text-sm font-bold shadow-lg shadow-hc-blue/25 hover:-translate-y-0.5 transition-all"
          >
            Voir les annonces
          </Link>
          <button
            onClick={() => setSubmitted(false)}
            className="px-6 py-2.5 rounded-xl border border-white/15 bg-white/[0.04] text-white text-sm font-semibold hover:border-hc-cyan hover:text-hc-cyan transition-all"
          >
            Publier une autre annonce
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pt-14 max-w-2xl mx-auto px-4 py-8">
      <Link
        href="/emploi"
        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-white/[0.08] bg-white/[0.03] text-white/50 text-[13px] font-semibold hover:border-hc-blue hover:text-hc-blue transition-all mb-5"
      >
        ← Retour aux annonces
      </Link>

      <div className="bg-white/[0.03] border border-white/[0.06] rounded-2xl p-7 animate-fade-up">
        <h1 className="text-xl font-extrabold mb-1">📝 Déposer une annonce</h1>
        <p className="text-[13px] text-white/45 mb-6">
          Remplissez les informations ci-dessous pour publier votre offre sur
          HandballConnect.
        </p>

        {/* Poste info */}
        <SectionLabel>Informations du poste</SectionLabel>
        <div className="mb-3">
          <Label>Intitulé du poste *</Label>
          <input
            className={inputClass}
            placeholder="Ex: Entraîneur Senior Garçons"
          />
        </div>
        <div className="grid sm:grid-cols-2 gap-3 mb-3">
          <div>
            <Label>Type de poste *</Label>
            <select className={inputClass}>
              <option value="">Choisir...</option>
              {POST_TYPES.map((p) => (
                <option key={p}>{p}</option>
              ))}
            </select>
          </div>
          <div>
            <Label>Type de contrat *</Label>
            <select className={inputClass}>
              <option value="">Choisir...</option>
              {CONTRACT_TYPES.map((c) => (
                <option key={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="mb-3">
          <Label>Niveau / Catégorie</Label>
          <input
            className={inputClass}
            placeholder="Ex: Excellence Régionale, Catégories jeunes..."
          />
        </div>
        <div className="mb-3">
          <Label>Description du poste *</Label>
          <textarea
            className={`${inputClass} min-h-[120px] resize-y`}
            placeholder="Décrivez les missions, les horaires d'entraînement, le profil recherché..."
          />
        </div>
        <div className="mb-6">
          <Label>Citation / Mot du club</Label>
          <input
            className={inputClass}
            placeholder="Ex: Un club ambitieux avec un vrai projet sportif..."
          />
        </div>

        {/* Club info */}
        <SectionLabel>Informations du club</SectionLabel>
        <div className="grid sm:grid-cols-2 gap-3 mb-6">
          <div>
            <Label>Nom du club *</Label>
            <input
              className={inputClass}
              placeholder="Ex: US Meyzieu Handball"
            />
          </div>
          <div>
            <Label>Département *</Label>
            <select className={inputClass}>
              <option value="">Choisir...</option>
              {Object.entries(DEPARTMENTS).map(([k, v]) => (
                <option key={k} value={k}>
                  {v} ({k})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Contact */}
        <SectionLabel>Contact</SectionLabel>
        <div className="grid sm:grid-cols-2 gap-3 mb-3">
          <div>
            <Label>Nom du contact</Label>
            <input className={inputClass} placeholder="Prénom NOM" />
          </div>
          <div>
            <Label>Fonction</Label>
            <input
              className={inputClass}
              placeholder="Ex: Président, DT..."
            />
          </div>
        </div>
        <div className="grid sm:grid-cols-2 gap-3 mb-6">
          <div>
            <Label>Email *</Label>
            <input
              className={inputClass}
              type="email"
              placeholder="contact@club.com"
            />
          </div>
          <div>
            <Label>Téléphone</Label>
            <input
              className={inputClass}
              placeholder="06 XX XX XX XX"
            />
          </div>
        </div>

        <button
          onClick={() => setSubmitted(true)}
          className="px-7 py-3 rounded-xl bg-gradient-to-br from-hc-blue to-blue-700 text-white text-sm font-bold shadow-lg shadow-hc-blue/25 hover:-translate-y-0.5 hover:shadow-hc-blue/40 transition-all"
        >
          Publier l&apos;annonce 🚀
        </button>
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] uppercase tracking-[1.2px] text-white/30 font-bold mb-3">
      {children}
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <label className="block text-[12px] font-semibold text-white/50 mb-1">
      {children}
    </label>
  );
}
