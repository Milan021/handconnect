"use client";

import { useEffect, useRef, useState } from "react";

function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) setVisible(true);
      },
      { threshold: 0.15 }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(28px)",
        transition: `opacity 0.6s ease ${delay}s, transform 0.6s ease ${delay}s`,
      }}
    >
      {children}
    </div>
  );
}

function Tag({ children, color }: { children: React.ReactNode; color: string }) {
  return (
    <span
      className={`px-3 py-1 rounded-lg text-[11px] font-bold tracking-wide uppercase ${color}`}
    >
      {children}
    </span>
  );
}

const features = [
  {
    id: "emploi",
    icon: "🏢",
    title: "Emploi & Recrutement",
    desc: "La première plateforme emploi dédiée au handball en AURA. Les clubs publient leurs offres, les coachs et bénévoles candidatent directement. Filtres par département, poste, type de contrat et carte interactive.",
    tags: [
      { label: "Offres en temps réel", color: "bg-hc-blue/10 text-hc-blue" },
      { label: "Candidature en ligne", color: "bg-hc-cyan/10 text-emerald-400" },
      { label: "Carte des clubs", color: "bg-white/5 text-white/50" },
    ],
    visual: (
      <div className="bg-gradient-to-br from-navy-mid to-navy rounded-2xl p-5 flex flex-col gap-2.5 h-full">
        {[
          { t: "Entraîneur Senior Garçons", m: "US Meyzieu · Rhône · Bénévole" },
          { t: "Coachs Jeunes H/F", m: "HB Trévoux · Ain · Bénévole" },
          { t: "Entraîneur Pré-Nationale", m: "HBC Romanais · Drôme · Bénévole" },
          { t: "Staff Technique", m: "Cheyenne HB · Savoie · Bénévole" },
        ].map((j) => (
          <div
            key={j.t}
            className="bg-white/[0.04] border border-white/[0.06] rounded-xl px-4 py-3 hover:bg-hc-blue/[0.08] hover:border-hc-blue/20 transition-all"
          >
            <div className="text-[13px] font-bold">{j.t}</div>
            <div className="text-[11px] text-white/30">{j.m}</div>
          </div>
        ))}
      </div>
    ),
    reverse: false,
  },
  {
    id: "annuaire",
    icon: "📖",
    title: "Annuaire des Clubs",
    desc: "Retrouvez tous les clubs de la région avec leurs coordonnées, créneaux d'entraînement, catégories d'âge, niveaux de compétition et contacts. Un outil indispensable pour joueurs, parents et partenaires.",
    tags: [
      { label: "850+ clubs", color: "bg-hc-cyan/10 text-emerald-400" },
      { label: "Fiches détaillées", color: "bg-hc-orange/10 text-orange-400" },
      { label: "Recherche géolocalisée", color: "bg-white/5 text-white/50" },
    ],
    visual: (
      <div className="bg-gradient-to-br from-[#0a1f1a] to-navy rounded-2xl p-5 grid grid-cols-2 gap-2.5 h-full">
        {[
          { e: "🔵", n: "US Meyzieu HB", d: "Rhône (69)" },
          { e: "🟢", n: "Pays Voironnais", d: "Isère (38)" },
          { e: "🟠", n: "HBC Romanais", d: "Drôme (26)" },
          { e: "🔴", n: "HC Rumilly", d: "Hte-Savoie (74)" },
          { e: "🟡", n: "Cheyenne HB", d: "Savoie (73)" },
          { e: "🟣", n: "Bron Handball", d: "Rhône (69)" },
        ].map((c) => (
          <div
            key={c.n}
            className="bg-white/[0.04] border border-white/[0.06] rounded-xl p-3.5 text-center hover:bg-hc-cyan/[0.06] hover:border-hc-cyan/15 transition-all"
          >
            <div className="text-xl mb-1">{c.e}</div>
            <div className="text-[11.5px] font-bold">{c.n}</div>
            <div className="text-[10px] text-white/30">{c.d}</div>
          </div>
        ))}
      </div>
    ),
    reverse: true,
  },
  {
    id: "actus",
    icon: "📰",
    title: "Actualités",
    desc: "Suivez toute l'actualité du handball en Auvergne-Rhône-Alpes : transferts, résultats de coupes, formations fédérales, vie des clubs et événements de la ligue.",
    tags: [
      { label: "Flux en direct", color: "bg-hc-orange/10 text-orange-400" },
      { label: "Ligue & clubs", color: "bg-hc-yellow/10 text-yellow-400" },
      { label: "Notifications", color: "bg-white/5 text-white/50" },
    ],
    visual: (
      <div className="bg-gradient-to-br from-[#1a0f05] to-navy rounded-2xl p-5 flex flex-col gap-2.5 h-full">
        {[
          { e: "🏆", bg: "bg-yellow-500/10", t: "Phase finale N2 : le programme", d: "Il y a 2h" },
          { e: "📋", bg: "bg-hc-blue/10", t: "Transferts : mouvements en AURA", d: "Il y a 5h" },
          { e: "🎓", bg: "bg-hc-cyan/10", t: "Formation CQP animateur", d: "Hier" },
          { e: "🤝", bg: "bg-hc-orange/10", t: "AG ligue — les temps forts", d: "Il y a 3j" },
        ].map((a) => (
          <div
            key={a.t}
            className="bg-white/[0.04] border border-white/[0.06] rounded-xl px-4 py-3 flex gap-3 items-center hover:bg-hc-orange/[0.06] hover:border-hc-orange/15 transition-all"
          >
            <div
              className={`w-9 h-9 rounded-lg ${a.bg} flex items-center justify-center text-base shrink-0`}
            >
              {a.e}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[12px] font-bold truncate">{a.t}</div>
              <div className="text-[10px] text-white/30">{a.d}</div>
            </div>
          </div>
        ))}
      </div>
    ),
    reverse: false,
  },
  {
    id: "resultats",
    icon: "📊",
    title: "Résultats & Classements",
    desc: "Scores en direct, classements par division, statistiques des équipes et calendrier des matchs. Toutes les compétitions régionales au même endroit.",
    tags: [
      { label: "Scores live", color: "bg-hc-yellow/10 text-yellow-400" },
      { label: "Classements", color: "bg-hc-blue/10 text-hc-blue" },
      { label: "Calendrier", color: "bg-white/5 text-white/50" },
    ],
    visual: (
      <div className="bg-gradient-to-br from-[#1a1505] to-navy rounded-2xl p-5 flex flex-col gap-2 h-full">
        <div className="text-[10px] text-white/30 uppercase tracking-[1.5px] font-bold mb-1">
          Excellence Régionale
        </div>
        {[
          { a: "US Meyzieu", b: "HC Rumilly", s: "28 - 24" },
          { a: "Pays Voironnais", b: "Cheyenne HB", s: "31 - 31" },
          { a: "HBC Romanais", b: "Bron HB", s: "26 - 22" },
          { a: "BVSH", b: "HB Trévoux", s: "33 - 19" },
        ].map((m) => (
          <div
            key={m.a + m.b}
            className="bg-white/[0.04] border border-white/[0.06] rounded-xl px-4 py-2.5 flex items-center justify-between gap-2 hover:bg-hc-yellow/[0.06] hover:border-hc-yellow/15 transition-all"
          >
            <span className="text-[12px] font-bold flex-1">{m.a}</span>
            <span className="px-3 py-1 rounded-lg bg-white/[0.06] text-sm font-[900] tracking-wider min-w-[70px] text-center">
              {m.s}
            </span>
            <span className="text-[12px] font-bold flex-1 text-right">
              {m.b}
            </span>
          </div>
        ))}
      </div>
    ),
    reverse: true,
  },
];

export function Features() {
  return (
    <section className="py-20 px-6 max-w-6xl mx-auto">
      <Reveal>
        <div className="text-hc-blue text-[11px] uppercase tracking-[2px] font-extrabold mb-3">
          ⚡ Fonctionnalités
        </div>
        <h2 className="text-[clamp(28px,4vw,40px)] font-[900] leading-[1.1] tracking-tight max-w-xl mb-12">
          Quatre piliers pour{" "}
          <span className="text-hc-cyan">connecter</span> le handball.
        </h2>
      </Reveal>

      {features.map((f, i) => (
        <div
          key={f.id}
          id={f.id}
          className={`grid md:grid-cols-2 gap-10 items-center mb-20 ${
            f.reverse ? "md:[direction:rtl]" : ""
          }`}
        >
          <Reveal className={f.reverse ? "md:[direction:ltr]" : ""}>
            <div className="aspect-[4/3] rounded-2xl overflow-hidden">
              {f.visual}
            </div>
          </Reveal>
          <Reveal
            delay={0.15}
            className={f.reverse ? "md:[direction:ltr]" : ""}
          >
            <div>
              <h3 className="text-2xl font-extrabold tracking-tight mb-3">
                {f.icon} {f.title}
              </h3>
              <p className="text-[15px] text-white/50 leading-relaxed mb-5">
                {f.desc}
              </p>
              <div className="flex gap-2 flex-wrap">
                {f.tags.map((t) => (
                  <Tag key={t.label} color={t.color}>
                    {t.label}
                  </Tag>
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      ))}
    </section>
  );
}
