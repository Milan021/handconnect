import Link from "next/link";

export function CtaSection() {
  return (
    <section className="py-20 px-6 text-center relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_100%,rgba(26,122,255,0.1),transparent_60%)]" />
      <div className="relative max-w-lg mx-auto">
        <h2 className="text-[clamp(28px,4vw,42px)] font-[900] tracking-tight leading-[1.1] mb-4">
          Prêt à rejoindre
          <br />
          le <span className="text-hc-cyan">réseau</span> ?
        </h2>
        <p className="text-base text-white/50 mb-8 leading-relaxed">
          Que vous soyez club, entraîneur, joueur ou passionné —
          HandballConnect est votre espace handball.
        </p>
        <div className="flex gap-3.5 justify-center flex-wrap">
          <Link
            href="/emploi"
            className="px-8 py-3.5 rounded-xl bg-gradient-to-br from-hc-blue to-blue-700 text-white text-[15px] font-bold shadow-lg shadow-hc-blue/25 hover:-translate-y-0.5 transition-all"
          >
            Créer mon compte gratuitement
          </Link>
          <Link
            href="/emploi/poster"
            className="px-8 py-3.5 rounded-xl border border-white/15 bg-white/[0.04] text-white text-[15px] font-semibold hover:border-hc-cyan hover:text-hc-cyan transition-all"
          >
            Je suis un club →
          </Link>
        </div>
      </div>
    </section>
  );
}
