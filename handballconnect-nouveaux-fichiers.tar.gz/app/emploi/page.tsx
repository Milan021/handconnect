"use client";

import { useState } from "react";
import { ANNONCES, DEPARTMENTS, type Annonce } from "@/lib/data";
import { AnnonceCard } from "@/components/emploi/AnnonceCard";
import { AnnonceFilters } from "@/components/emploi/AnnonceFilters";

export default function EmploiPage() {
  const [search, setSearch] = useState("");
  const [dept, setDept] = useState("");
  const [postType, setPostType] = useState("");
  const [contractType, setContractType] = useState("");

  const filtered = ANNONCES.filter((a) => {
    if (dept && a.dept !== dept) return false;
    if (postType && a.postType !== postType) return false;
    if (contractType && a.contractType !== contractType) return false;
    if (search) {
      const s = search.toLowerCase();
      if (
        !(a.title + a.club + a.description + a.level + a.deptName)
          .toLowerCase()
          .includes(s)
      )
        return false;
    }
    return true;
  });

  const uniqueDepts = [...new Set(ANNONCES.map((a) => a.dept))];
  const uniqueClubs = [...new Set(ANNONCES.map((a) => a.club))];

  return (
    <div className="pt-14">
      {/* Hero */}
      <div className="relative text-center px-6 pt-12 pb-10 overflow-hidden bg-gradient-to-b from-navy to-navy-mid">
        <div className="absolute top-[-80px] right-[-60px] w-[300px] h-[300px] rounded-full bg-hc-cyan/[0.06] blur-[80px]" />
        <div className="absolute bottom-[-40px] left-[-40px] w-[200px] h-[200px] rounded-full bg-hc-orange/[0.04] blur-[80px]" />

        <h1 className="relative text-3xl sm:text-4xl font-[900] tracking-tight leading-tight mb-2.5">
          Trouvez votre place
          <br />
          dans le <span className="text-hc-cyan">handball</span>
        </h1>
        <p className="relative text-sm text-white/45 max-w-md mx-auto mb-6">
          La plateforme emploi dédiée aux clubs et passionnés de handball en
          Auvergne-Rhône-Alpes
        </p>

        {/* Stats */}
        <div className="relative flex gap-7 justify-center">
          {[
            { v: ANNONCES.length, l: "Annonces" },
            { v: uniqueClubs.length, l: "Clubs" },
            { v: uniqueDepts.length, l: "Départements" },
          ].map((s) => (
            <div key={s.l} className="text-center">
              <strong className="block text-2xl font-[900]">{s.v}</strong>
              <small className="text-[10px] text-white/35 uppercase tracking-[1px] font-bold">
                {s.l}
              </small>
            </div>
          ))}
        </div>
      </div>

      {/* Content */}
      <div className="max-w-3xl mx-auto px-4 py-6">
        <AnnonceFilters
          search={search}
          dept={dept}
          postType={postType}
          contractType={contractType}
          onSearch={setSearch}
          onDept={setDept}
          onPostType={setPostType}
          onContractType={setContractType}
        />

        <p className="text-[13px] text-white/35 font-medium mb-3.5">
          {filtered.length} annonce{filtered.length > 1 ? "s" : ""} trouvée
          {filtered.length > 1 ? "s" : ""}
        </p>

        <div className="flex flex-col gap-3.5">
          {filtered.length === 0 ? (
            <div className="text-center py-12 text-white/35">
              <div className="text-4xl mb-2.5">🔍</div>
              <div className="text-[15px] font-semibold">
                Aucune annonce ne correspond
              </div>
              <div className="text-[13px] mt-1">
                Essayez de modifier vos filtres
              </div>
            </div>
          ) : (
            filtered.map((a) => <AnnonceCard key={a.id} annonce={a} />)
          )}
        </div>
      </div>
    </div>
  );
}
