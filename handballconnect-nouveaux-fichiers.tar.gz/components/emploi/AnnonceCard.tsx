import Link from "next/link";
import { Badge } from "@/components/ui/Badge";
import { formatDate, type Annonce } from "@/lib/data";

export function AnnonceCard({ annonce }: { annonce: Annonce }) {
  return (
    <Link
      href={`/emploi/${annonce.id}`}
      className="block bg-white/[0.03] border border-white/[0.06] rounded-2xl overflow-hidden hover:border-hc-blue/20 hover:bg-white/[0.05] hover:-translate-y-0.5 hover:shadow-lg hover:shadow-hc-blue/[0.06] transition-all"
    >
      {/* Header */}
      <div className="px-5 pt-4 pb-3">
        <div className="flex gap-1.5 flex-wrap mb-2">
          <Badge variant="blue">{annonce.postType}</Badge>
          <Badge variant="cyan">{annonce.contractType}</Badge>
          {annonce.level && <Badge variant="gray">{annonce.level}</Badge>}
        </div>
        <h3 className="text-base font-bold leading-snug">{annonce.title}</h3>
        <p className="text-[13.5px] text-white/45 font-medium">
          {annonce.club} — {annonce.deptName} ({annonce.dept})
        </p>
      </div>

      {/* Description */}
      <div className="px-5 pb-3">
        <p className="text-[13px] text-white/40 leading-relaxed line-clamp-2">
          {annonce.description}
        </p>
      </div>

      {/* Footer */}
      <div className="px-5 py-2.5 bg-white/[0.02] border-t border-white/[0.04] flex justify-between items-center">
        <span className="text-[11.5px] text-white/30">
          📅 {formatDate(annonce.date)}
        </span>
        {annonce.contactEmail && (
          <span className="text-[12px] text-hc-blue font-semibold">
            ✉ Postuler →
          </span>
        )}
      </div>
    </Link>
  );
}
