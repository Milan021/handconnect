"use client";

import { useEffect, useRef, useState } from "react";

function Counter({
  target,
  suffix = "",
}: {
  target: number;
  suffix?: string;
}) {
  const [val, setVal] = useState(0);
  const ref = useRef<HTMLSpanElement>(null);
  const counted = useRef(false);

  useEffect(() => {
    if (!ref.current) return;
    const obs = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting && !counted.current) {
          counted.current = true;
          let start = 0;
          const step = target / 110;
          const id = setInterval(() => {
            start += step;
            if (start >= target) {
              setVal(target);
              clearInterval(id);
            } else {
              setVal(Math.floor(start));
            }
          }, 16);
        }
      },
      { threshold: 0.3 }
    );
    obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target]);

  return (
    <span ref={ref}>
      {val}
      {suffix}
    </span>
  );
}

const stats = [
  { label: "Offres actives", value: 10, suffix: "+", color: "text-hc-blue" },
  { label: "Clubs en AURA", value: 850, suffix: "", color: "text-hc-cyan" },
  { label: "Départements", value: 12, suffix: "", color: "text-hc-orange" },
  { label: "Licenciés", value: 45, suffix: "k", color: "text-hc-yellow" },
];

export function StatsBar() {
  return (
    <div className="flex justify-center bg-gradient-to-r from-navy-mid to-navy-light border-y border-white/[0.04]">
      {stats.map((s, i) => (
        <div
          key={s.label}
          className="flex-1 max-w-[220px] text-center py-7 px-4 relative"
        >
          {i > 0 && (
            <div className="absolute left-0 top-[30%] bottom-[30%] w-px bg-white/[0.06]" />
          )}
          <strong
            className={`block text-4xl font-[900] tracking-tight ${s.color}`}
          >
            <Counter target={s.value} suffix={s.suffix} />
          </strong>
          <small className="text-[11px] text-white/30 uppercase tracking-[1.5px] font-bold">
            {s.label}
          </small>
        </div>
      ))}
    </div>
  );
}
