export function Footer() {
  return (
    <footer className="py-9 px-6 text-center border-t border-white/[0.04] bg-black/20">
      <p className="text-xs text-white/30">
        © 2026 HandballConnect —{" "}
        <a href="https://handconnect.fr" className="text-white/50 hover:text-hc-cyan transition-colors">
          handconnect.fr
        </a>{" "}
        · Opéré par SASU Joker Team · Fait avec 🤾 pour le handball en AURA
      </p>
    </footer>
  );
}
