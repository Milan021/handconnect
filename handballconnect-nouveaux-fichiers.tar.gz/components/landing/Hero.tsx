import Link from "next/link";

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center text-center px-6 pt-24 pb-20 overflow-hidden">
      {/* Background effects */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
          maskImage:
            "radial-gradient(ellipse at center, black 30%, transparent 70%)",
          WebkitMaskImage:
            "radial-gradient(ellipse at center, black 30%, transparent 70%)",
        }}
      />
      <div className="absolute -top-[10%] -left-[5%] w-[400px] h-[400px] rounded-full bg-hc-blue/[0.06] blur-[80px] animate-float" />
      <div className="absolute bottom-0 -right-[5%] w-[300px] h-[300px] rounded-full bg-hc-cyan/[0.05] blur-[80px] animate-float [animation-delay:3s]" />
      <div className="absolute top-[30%] right-[20%] w-[200px] h-[200px] rounded-full bg-hc-orange/[0.04] blur-[80px] animate-float [animation-delay:5s]" />

      {/* Content */}
      <div className="relative max-w-2xl">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-hc-cyan/[0.08] border border-hc-cyan/15 text-hc-cyan text-xs font-bold tracking-wider uppercase mb-6">
          <span className="w-1.5 h-1.5 rounded-full bg-hc-cyan animate-glow-pulse" />
          Plateforme handball — Auvergne-Rhône-Alpes
        </div>

        <h1 className="text-[clamp(38px,7vw,64px)] font-[900] leading-[1.05] tracking-[-2px] mb-5">
          Le handball
          <br />
          a son{" "}
          <span className="bg-gradient-to-r from-hc-cyan to-hc-blue bg-clip-text text-transparent">
            réseau
          </span>
          .
        </h1>

        <p className="text-[17px] text-white/50 leading-relaxed max-w-lg mx-auto mb-8">
          Emploi, annuaire des clubs, actualités et résultats : tout
          l&apos;écosystème handball réuni sur une seule plateforme.
        </p>

        <div className="flex gap-3.5 justify-center flex-wrap">
          <Link
            href="/emploi"
            className="px-8 py-3.5 rounded-xl bg-gradient-to-br from-hc-blue to-blue-700 text-white text-[15px] font-bold shadow-lg shadow-hc-blue/25 hover:-translate-y-0.5 hover:shadow-hc-blue/40 transition-all"
          >
            Découvrir la plateforme
          </Link>
          <Link
            href="/emploi"
            className="px-8 py-3.5 rounded-xl border border-white/15 bg-white/[0.04] text-white text-[15px] font-semibold backdrop-blur hover:border-hc-cyan hover:text-hc-cyan hover:bg-hc-cyan/[0.05] transition-all"
          >
            Voir les offres d&apos;emploi
          </Link>
        </div>
      </div>
    </section>
  );
}
